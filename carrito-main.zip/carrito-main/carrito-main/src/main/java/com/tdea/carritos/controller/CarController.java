package com.tdea.carritos.controller;

import java.util.Collection;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tdea.carritos.modelo.Car;
import com.tdea.carritos.repository.CarRepository;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class CarController {

    @Autowired
    private CarRepository repository;

    @GetMapping("/cool-cars")
    public Collection<Car> coolCars() {
        return repository.findAll()
                .stream()
                .filter(this::isCool)
                .collect(Collectors.toList());
    }

    // Devuelve TODOS los carros (sin filtrar), para mostrarlos en la vista principal
    @GetMapping("/cars")
    public Collection<Car> allCars() {
        return repository.findAll();
    }

    // Crea un nuevo carro
    @PostMapping("/cars")
    public Car createCar(@RequestBody Car car) {
        return repository.save(car);
    }

    // Actualiza un carro existente
    @PutMapping("/cars/{id}")
    public ResponseEntity<Car> updateCar(@PathVariable Long id, @RequestBody Car carDetails) {
        return repository.findById(id)
                .map(car -> {
                    car.setNombre(carDetails.getNombre());
                    car.setModelo(carDetails.getModelo());
                    car.setColor(carDetails.getColor());
                    car.setPrecio(carDetails.getPrecio());
                    Car updated = repository.save(car);
                    return ResponseEntity.ok(updated);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    private boolean isCool(Car car) {
        return !car.getNombre().equals("AMC Gremlin") &&
                !car.getNombre().equals("Ford Pinto") &&
                !car.getNombre().equals("Triumph Stag") &&
                !car.getNombre().equals("Yugo GV");
    }
}