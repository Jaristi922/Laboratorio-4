package com.tdea.carritos;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.tdea.carritos.modelo.Car;
import com.tdea.carritos.repository.CarRepository;

@SpringBootApplication
public class CarritosApplication {

    public static void main(String[] args) {
        SpringApplication.run(CarritosApplication.class, args);
    }

    @Bean
    ApplicationRunner init(CarRepository repository) {
        return args -> {
            repository.save(new Car(null, "Ferrari", "488 GTB", "Rojo", 280000.0));
            repository.save(new Car(null, "Jaguar Car", "F-Type", "Verde", 95000.0));
            repository.save(new Car(null, "Porsche", "911 Carrera", "Blanco", 120000.0));
            repository.save(new Car(null, "Lamborghini", "Huracán", "Amarillo", 260000.0));
            repository.save(new Car(null, "Bugatti", "Chiron", "Azul", 3000000.0));
            repository.save(new Car(null, "AMC Gremlin", "Base", "Naranja", 5000.0));
            repository.save(new Car(null, "Triumph Stag", "Base", "Beige", 8000.0));
            repository.save(new Car(null, "Ford Pinto", "Base", "Café", 4000.0));
            repository.save(new Car(null, "Yugo GV", "Base", "Gris", 3000.0));

            repository.findAll().forEach(System.out::println);
        };
    }
}