import React from 'react';
import './App.css';
import CarList from './CarList';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Catálogo de Carros</h1>
      </header>
      <CarList />
    </div>
  );
}

export default App;