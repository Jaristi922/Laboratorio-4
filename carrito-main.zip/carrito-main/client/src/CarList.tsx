import React, { useState, useEffect } from 'react';

interface Car {
  id: number;
  nombre: string;
  modelo: string;
  color: string;
  precio: number;
}

const CarList: React.FC = () => {
  const [cars, setCars] = useState<Car[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Estado del formulario
  const [nombre, setNombre] = useState<string>('');
  const [modelo, setModelo] = useState<string>('');
  const [color, setColor] = useState<string>('');
  const [precio, setPrecio] = useState<string>('');
  const [editingId, setEditingId] = useState<number | null>(null);

  const fetchCars = () => {
    setIsLoading(true);
    fetch('http://localhost:8080/cars')
      .then(response => response.json())
      .then(data => {
        setCars(data);
        setIsLoading(false);
      });
  };

  useEffect(() => {
    fetchCars();
  }, []);

  const limpiarFormulario = () => {
    setNombre('');
    setModelo('');
    setColor('');
    setPrecio('');
    setEditingId(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const carData = {
      nombre,
      modelo,
      color,
      precio: parseFloat(precio),
    };

    if (editingId === null) {
      // Crear (POST)
      fetch('http://localhost:8080/cars', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(carData),
      })
        .then(response => response.json())
        .then(() => {
          fetchCars();
          limpiarFormulario();
        });
    } else {
      // Editar (PUT)
      fetch(`http://localhost:8080/cars/${editingId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(carData),
      })
        .then(response => response.json())
        .then(() => {
          fetchCars();
          limpiarFormulario();
        });
    }
  };

  const handleEdit = (car: Car) => {
    setEditingId(car.id);
    setNombre(car.nombre);
    setModelo(car.modelo);
    setColor(car.color);
    setPrecio(car.precio.toString());
  };

  const handleCancelEdit = () => {
    limpiarFormulario();
  };

  if (isLoading) {
    return <p>Cargando...</p>;
  }

  return (
    <div>
      <h2>{editingId === null ? 'Agregar Carro' : 'Editar Carro'}</h2>

      <form onSubmit={handleSubmit} style={{ marginBottom: '20px' }}>
        <input
          type="text"
          placeholder="Nombre"
          value={nombre}
          onChange={e => setNombre(e.target.value)}
          required
        />
        <input
          type="text"
          placeholder="Modelo"
          value={modelo}
          onChange={e => setModelo(e.target.value)}
        />
        <input
          type="text"
          placeholder="Color"
          value={color}
          onChange={e => setColor(e.target.value)}
        />
        <input
          type="number"
          placeholder="Precio"
          value={precio}
          onChange={e => setPrecio(e.target.value)}
          step="0.01"
        />
        <button type="submit">
          {editingId === null ? 'Crear' : 'Actualizar'}
        </button>
        {editingId !== null && (
          <button type="button" onClick={handleCancelEdit}>
            Cancelar
          </button>
        )}
      </form>

      <h2>Lista de Carros</h2>
      <table border={1} cellPadding={8} style={{ margin: '0 auto' }}>
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Modelo</th>
            <th>Color</th>
            <th>Precio</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {cars.map((car: Car) => (
            <tr key={car.id}>
              <td>{car.nombre}</td>
              <td>{car.modelo}</td>
              <td>{car.color}</td>
              <td>${car.precio}</td>
              <td>
                <button onClick={() => handleEdit(car)}>Editar</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CarList;